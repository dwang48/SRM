from django.apps import AppConfig


class CostAnalysisConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "cost_analysis"
    verbose_name = "成本计算模版"
